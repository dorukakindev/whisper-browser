# Gece denetimi koordinasyon sözleşmesi (1000 senaryo)

Bu dosya, altı denetim işçisinin ortak kuralıdır. `GLOBAL-KURALLAR.md` ve `BASLA.md` bağlayıcıdır; bu dosya onları özetler ve klasör düzenini sabitler.

## Kaynak ve sınırlar

- Kaynak depo: `D:\Whisper Local` (HEAD koşu başında `logs/start-head.txt`).
- **Ürün kodu, mevcut testler, package.json/package-lock, backend venv ve global sistem ayarları DEĞİŞTİRİLMEZ.** Commit/push/merge/pull/reset/stash/clean yok.
- Kişisel profil/oturum/çerez/anahtar/medya/kitap/SRT/sohbet okuma veya dışarı gönderme yok. Sentetik fixture + izole `WHISPER_RESOURCE_SOAK_USER_DATA` kullan.
- Canlı ücretli API, GPU/model indirme, gerçek YouTube/Letterboxd/Cloudflare varsayılan olarak NOT_RUN/BLOCKED_ENV.
- Başka sohbete/Codex'e mesaj yok. Bu çalışma yalnız raporlama içindir; fix/patch yok.

## Klasör düzeni (bu run)

Kök: `docs/raporlar/DEEPSEEK-NIGHT1000-20261027T0441Z-n1k7/`
- `1000-SENARYO.csv` — yalnız bu kopyanın `status,evidence,finding_ids,reason` sütunları güncellenir. Kaynak CSV'ye dokunma.
- `pkgNN/` — paket çıktıları: `AUDIT-REPORT.md`, `FINDINGS.json`, `TASK-MATRIX.csv` (paket satırları), `CHECKPOINT.md`, `evidence/` (trace, screenshot, fixture).
- `logs/` — `probes/run.py`'nin yazdığı stdout/stderr.
- `RUN-LOG.jsonl` — TEK global log; her komut buraya düşer (`task` alanı `pkgNN`).
- `probes/` — kendi prob/fixture üreticilerin. Ürün modülünü kopyalama, import et.
- `tools/` — ayrı test araçları (npm prefix / venv). Kurulumlar `TOOLS.md`'ye yazılır.
- `checkpoints/` — her 100 satırlık paket sonunda `pkgNN.zip`.

## Satır işleme protokolü (zorunlu)

1. Paket dosyasındaki 100 satırı ve CSV'deki `batch=NN` satırlarını **sırayla** işle. İlk 5 satırdan sonra bırakma.
2. Her satır için önce **uygulanabilirlik** kontrolü: kaynak dosya/özellik gerçekten var mı? Yoksa/ anlamsız kombinasyonsa `NOT_APPLICABLE` + teknik `reason` (bug/PASS sayılmaz).
3. Uygulanabilir satırı gerçekten koş: mevcut test, gerçek modülü import eden minimal prob, veya gerçek Electron/native harness. **Tasarlanan senaryo koşulmuş sayılmaz.**
4. Komutları `probes/run.py` ile çalıştır:
   ```powershell
   python "docs\raporlar\DEEPSEEK-NIGHT1000-20261027T0441Z-n1k7\probes\run.py" --task pkg01 --id N0001 --desc "..." -- node "D:\Whisper Local\tests\foo.test.js"
   ```
   Çıktı: `[pkg01-N0001] exit=0 timed_out=False ...` + `RUN-LOG.jsonl` satırı.
5. Durumlar: `PASS` (koşuldu ve sözleşme geçti), `FAIL_CONFIRMED` (koşuldu, ürün hatası kanıtlı), `SUSPECTED` (koşulmadı/şüphe), `BLOCKED_ENV`, `INCONCLUSIVE`, `MIXED_REVISION`, `NOT_RUN`, `SKIPPED_ALREADY_COVERED` (eşdeğer kanıt + açık referans), `NOT_APPLICABLE`.
6. Aynı kökü farklı satırlarda bulursan tek finding id + `duplicate_of`. 20 varyant = 20 kök değil.
7. Kendi probun hatalıysa düzelt ve ilk yanlış varsayımı `CHECKPOINT.md`'ye yaz. Ürünü/testi değiştirerek yeşile boyama.
8. Mevcut test kırmızıysa (ör. harness kaynaklı) ürün kökünden ayır; testi değiştirme, kanıtla raporla.

## Kanıt kuralları

- Her PASS/FAIL satırının `evidence` alanında **gerçek** log dosyası veya `logs/<id>.stdout.txt` olmalı.
- FINDINGS yalnız FAIL_CONFIRMED/SUSPECTED kökleri taşır; öneriler ayrı.
- Ekran görüntüsü yalnız gerçek Electron penceresinden; statik HTML/native olmayan render görsel kabul değildir.
- Fixture başarısı gerçek model/GPU/site başarısı değildir.
- Full `npm test` tüm gece boyunca **en fazla bir kez**; her pakette tekrarlama.

## Checkpoint ve ZIP

- Her **25 satırda**: `pkgNN/CHECKPOINT.md` (biten id'ler, çalışan PID, eksik kanıt, kesin sonraki komut) + global `CHECKPOINT.md` güncelle.
- Her **100 satırda**: `pkgNN` klasörünü ve yalnız ona ait log/evidence dosyalarını `checkpoints/pkgNN.zip` içine al (node_modules/venv/model yok). ZIP'i python `zipfile` ile üret.
- Bağlam/tool limiti yaklaşırsa: tam kaldığın satır id'sini, sonraki komutu ve eksik kanıtı yaz; yarımı tamam sayma.

## Paketler arası devir

- Her işçi yalnız kendi paket aralığını işler; başka paketin `pkgNN` klasörüne yazmaz.
- Bitince `CHECKPOINT.md`'ye "bitti: N satır, PASS/FAIL/NOT_* sayıları, benzersiz kökler, sonraki paket" yaz.
- Global birleştirme (rapor, FINDINGS, manifest, ZIP) koordinatörde yapılır; işçi global ZIP üretmez.

## Önceki denetimle ilişki

- `docs/raporlar/DEEPSEEK-AUDIT-20261027T0242Z-coord-d0a1e655/` bulguları **güncel kaynakta yeniden doğrulanmadan** yeni bug sayılmaz; doğrulanırsa `duplicate_of` ile referans verilir.
- Rapor631 ayar modalı iptalini zaten giderir; ilgili senaryoları yeniden üretmeden FAIL yazma.
- Kaynak revizyonu koşu sırasında değişirse etkilenen koşular `MIXED_REVISION` sayılır.

## Araç kurulumu

- Önce mevcut Node/Electron/Python/Playwright düzenini keşfet. Gerekiyorsa resmî kaynaktan `tools/` altına kur (`npm install --prefix <tools>`, ayrı venv). Sürüm/boyut/neden/kurulum logu `TOOLS.md`'ye.
- Playwright ile gerçek Electron `_electron.launch` veya depo native harness tercih edilir. Kişisel uygulamaya CDP ile bağlanma.
- `--no-sandbox`/webSecurity kapatarak yeşile boyama yok; sınırı raporla.
