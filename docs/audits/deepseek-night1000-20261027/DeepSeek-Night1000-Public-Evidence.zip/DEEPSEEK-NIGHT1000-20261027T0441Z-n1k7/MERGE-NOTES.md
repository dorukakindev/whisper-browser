# Birleştirme notları (koordinatör)

Paket işçileri bittiğinde global rapor/manifest/ZIP üretirken uygula:

1. **B05-01 şema düzeltmesi:** `pkg05/FINDINGS.json` içinde `location` (tekil nesne) ve 16 karakterlik sha256 var. Global FINDINGS'e aktarırken:
   - `location` → `locations: [{file, line, symbol, sha256}]`
   - sha256'yı `D:\Whisper Local\tools\voxcpm2\dub_resume.py` dosyasından tam 64 karakter olarak yeniden hesapla.
   - `preconditions` dize ise diziye çevir.
2. **Eksik/şema dışı alanları tamamla:** her bulgu için id, severity, status, title, impact, preconditions[], actual, expected, locations[], repro{}, evidence[], root_cause, duplicate_of, minimal_fix_direction, related_tests.
3. **pkg05.zip eski:** N0441/N0459 SUSPECTED işaretlemesinden önce üretildi. Final paketlemede `checkpoints/pkg05.zip` pkg05 klasöründen yeniden üretilsin (ve diğer pkgNN.zip'ler güncel klasörlerden doğrulansın).
4. **İşçi A gözlemleri:** pkg01–03 FINDINGS boş; ancak AUDIT-REPORT'larda üç davranış gözlemi var (F14 diakritiksiz Türkçe kalite kapısı; F05 iptal sonrası delta; F07 evidenceOf yalnız `translation`). Bunları global FINDINGS'e **SUSPECTED** olarak, pkg raporlarındaki kanıt/konumla ekle (öneri olarak bırakma). Kanıt yoksa SUSPECTED + impact sınırı yaz.
5. **CSV:** 1000 satırın durumları yalnız `1000-SENARYO.csv` kopyasında; BOM korunmalı. Global TASK-MATRIX.csv bu 1000 satır + işçilerin pkg matrislerinden türetilmeli; sayılar buradan hesaplanmalı.
6. **Kaynak değişmezliği:** `git status --porcelain` başlangıç (`logs/start-git-status.txt`) ile karşılaştır; yalnız bu run klasörü yeni olmalı. Ürün/test değişikliği varsa raporla, geri alma.
7. **ZIP:** yalnız bu run klasörü içeriği; node_modules/venv/model/kişisel veri ve ZIP'in kendisi yok. Manifest kendisi+ZIP hariç tüm dosyaların boyut/sha256'sını taşısın. Checkpoint ZIP'leri final ZIP'e gömülmesin (klasörler yeterli).
8. **Rapor:** confirmed kökler / duplicate'ler / suspected / blocked / not-run / not-applicable ayrı sayılsın; tamamlanmamış satır PASS sayılmasın.

## REVIZYON (koşu sırasında değişti — kritik)
- Koşu başlangıcı: 7f3b0382c969ec183e7a7ebfddedf5d917c7b8ea (start-head.txt)
- Gözlenen ara HEAD: 19d5fb49 (PR #539) — işçi C tüm koşularını bunda yaptı
- Şu anki HEAD: 1b41451daaa4be1634965bb5b8edfa65f3f7400a (PR #540)
- Başka bir oturum gece boyunca commit atıyor (PR #539/#540). Bu bizim değişikliğimiz DEĞİL; geri alma yok.
- pkg01–pkg06: MIXED_REVISION (7f3b0382…19d5fb49 aralığında koştu; satır bazında kesin revizyon bilinmiyor). FAIL/SUSPECTED sonuçlar final HEAD'de yeniden doğrulanmadan kesin bug sayılmasın.
- pkg07–pkg08: 19d5fb49.
- pkg09–pkg10: işçi D'nin SNAPSHOT'ındaki start/end HEAD.
- Global SNAPSHOT.json start_head=7f3b0382, end_head=final HEAD, head_changed_during_run=true ve bu commit listesini taşımalı.
